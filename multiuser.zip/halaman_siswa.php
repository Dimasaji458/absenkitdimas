<!DOCTYPE html>
<html>
<head>
	<title>Halaman Siswa</title>
</head>
<body bgcolor="FF B6 C1">
	<?php 
	session_start();

	// cek apakah yang mengakses halaman ini sudah login
	if($_SESSION['level']==""){
		header("location:index.php?pesan=gagal");
	}

	?>
	<h1>Halaman Siswa</h1>

	<p>Halo <b><?php echo $_SESSION['username']; ?></b> Anda telah login sebagai <b><?php echo $_SESSION['level']; ?></b>.</p>
	<h4>Tabel Siswa</h4>
	<TABLE BORDER = "1">
		<TR><TH>No</TH><TH>nama_siswa</TH><TH>jurusan</TH></TR>
		<TR><TD>1</TD><TD>andi</TD><TH>tkj</TH></TR>
		<TR><TD>2</TD><TD>doni</TD><TH>tkj</TH></TR>
		<TR><TD>3</TD><TD>wahyu</TD><TH>tkj</TH></TR>
		<TR><TD>4</TD><TD>robert</TD><TH>tkj</TH></TR>
		<TR><TD>5</TD><TD>kaka</TD><TH>tkj</TH></TR>
</TABLE>
<br>
	<a href="logout.php">LogOut</a>

	<br/>
	<br/>
</html>